/*
   UDP Autosteer – Teensy 4.1 / AgOpenGPS
   WAS = różnica yaw: TM171 chassis (TM1_YawDeg) minus BNO085 knuckle (bnoDataWAS)
*/

////////////////// User Settings /////////////////////////

#define USE_BNO_WAS 1   // WAS z IMU (TM171 chassis + BNO085 knuckle)

#define LOW_HIGH_DEGREES 3.0

/*  PWM Frequency:  0 = 490 Hz,  1 = 122 Hz,  2 = 3921 Hz  */
#define PWM_Frequency 1

// WAS Calibration (używane tylko przy analogowym WAS – #else gałąź)
float inputWAS[]  = { -50,-45,-40,-35,-30,-25,-20,-15,-10,-5, 0, 5,10,15,20,25,30,35,40,45,50 };
float outputWAS[] = { -50,-45,-40,-35,-30,-25,-20,-15,-10,-5, 0, 5,10,15,20,25,30,35,40,45,50 };

/////////////////////////////////////////////

#define EEP_Ident 2400

#define DIR1_RL_ENABLE  4
#define PWM1_LPWM       2
#define PWM2_RPWM       3

#define STEERSW_PIN   32
#define WORKSW_PIN    34
#define REMOTE_PIN    37

#define CURRENT_SENSOR_PIN  A17
#define PRESSURE_SENSOR_PIN A10

#define CONST_180_DIVIDED_BY_PI 57.2957795130823

#include <Wire.h>
#include <EEPROM.h>
#include "zADS1115.h"
ADS1115_lite adc(ADS1115_DEFAULT_ADDRESS);

#include <IPAddress.h>
#ifdef ARDUINO_TEENSY41
#include <NativeEthernet.h>
#include <NativeEthernetUdp.h>
#endif

// TM1_YawDeg pochodzi z TM171.ino
extern volatile float TM1_YawDeg;

// bnoDataWAS pochodzi z głównego pliku (zadeklarowane tam jako BNO_rvcData bnoDataWAS)

// --- WAS FREEZE ---
#define FREEZE_SPEED_KMH  0.6f
#define FREEZE_TIME_MS    500
#define THAW_RATE_DPS     0.5f

// --- WAS source/jump protection ---
static const uint32_t WAS_SENSOR_FRESH_MS      = 250;
static const float    WAS_MAX_DELTA_STEP_DEG   = 45.0f;  // single-loop jump rejection; 0 disables
static const uint8_t  WAS_ACCEPT_BAD_AFTER_CNT = 0;      // 0 = never accept a repeated impossible jump

static bool     wasFrozen       = false;
static float    frozenWAS       = 0.0f;
static float    frozenDeltaBase = 0.0f;
static uint32_t stillStartMs    = 0;
static float    lastDeltaBase   = 0.0f;
static uint32_t lastDeltaMs     = 0;

// --- Auto-zero ---
static float    wasOffsetF   = 0.0f;
static uint32_t stableStart  = 0;

static const float    AUTOZERO_SPEED_MIN_KMH      = 1.0f;
static const uint32_t AUTOZERO_STRAIGHT_TIME_MS   = 5000;
static const float    AUTOZERO_YAWRATE_MAX_DPS    = 0.6f;
static const float    AUTOZERO_SETPOINT_MAX_DEG   = 3.0f;
static const float    AUTOZERO_FAST_FROM_DEG      = 5.0f;
static const float    AUTOZERO_SLOW_BETA          = 0.01f;
static const float    AUTOZERO_FAST_BETA          = 0.25f;
static const float    AUTOZERO_MAX_STEP_DEG       = 0.0f; // 0 = no correction step limit

uint8_t autoSteerUdpData[UDP_TX_PACKET_MAX_SIZE];

const uint16_t LOOP_TIME = 25;   // 40 Hz
uint32_t autsteerLastTime = LOOP_TIME;
uint32_t currentTime      = LOOP_TIME;

const uint16_t WATCHDOG_THRESHOLD   = 100;
const uint16_t WATCHDOG_FORCE_VALUE = WATCHDOG_THRESHOLD + 2;
uint8_t watchdogTimer = WATCHDOG_FORCE_VALUE;

uint8_t helloFromIMU[]       = { 128,129,121,121,5,0,0,0,0,0,71 };
uint8_t helloFromAutoSteer[] = { 0x80,0x81,126,126,5,0,0,0,0,0,71 };
int16_t helloSteerPosition   = 0;

uint8_t PGN_253[] = { 0x80,0x81,126,0xFD,8,0,0,0,0,0,0,0,0,0xCC };
int8_t  PGN_253_Size = sizeof(PGN_253) - 1;

uint8_t PGN_250[] = { 0x80,0x81,126,0xFA,8,0,0,0,0,0,0,0,0,0xCC };
int8_t  PGN_250_Size = sizeof(PGN_250) - 1;
uint8_t aog2Count = 0;
float   sensorReading;
float   sensorSample;

elapsedMillis gpsSpeedUpdateTimer = 0;

int16_t EEread = 0;

bool    isRelayActiveHigh = true;
uint8_t relay = 0, relayHi = 0, uTurn = 0;
uint8_t tram  = 0;

uint8_t remoteSwitch = 0, workSwitch = 0, steerSwitch = 1, switchByte = 0;

uint8_t guidanceStatus     = 0;
uint8_t prevGuidanceStatus = 0;
bool    guidanceStatusChanged = false;

float gpsSpeed = 0;

float   steerAngleActual   = 0;
float   steerAngleSetPoint = 0;
int16_t steeringPosition   = 0;
float   steerAngleError    = 0;

int16_t pwmDrive = 0, pwmDisplay = 0;
float   pValue = 0;
float   errorAbs = 0;
float   highLowPerDeg = 0;

uint8_t currentState = 1, reading, previous = 0;
uint8_t pulseCount = 0;
bool    encEnable  = false;
uint8_t thisEnc = 0, lastEnc = 0;

struct Storage {
    uint8_t Kp               = 40;
    uint8_t lowPWM           = 10;
    int16_t wasOffset        = 0;
    uint8_t minPWM           = 9;
    uint8_t highPWM          = 60;
    float   steerSensorCounts = 30;
    float   AckermanFix       = 1;
}; Storage steerSettings;

struct Setup {
    uint8_t InvertWAS         = 0;
    uint8_t IsRelayActiveHigh = 0;
    uint8_t MotorDriveDirection = 0;
    uint8_t SingleInputWAS    = 1;
    uint8_t CytronDriver      = 1;
    uint8_t SteerSwitch       = 0;
    uint8_t SteerButton       = 0;
    uint8_t ShaftEncoder      = 0;
    uint8_t PressureSensor    = 0;
    uint8_t CurrentSensor     = 0;
    uint8_t PulseCountMax     = 5;
    uint8_t IsDanfoss         = 0;
    uint8_t IsUseY_Axis       = 0;
}; Setup steerConfig;

void steerConfigInit()
{
    if (steerConfig.CytronDriver) pinMode(PWM2_RPWM, OUTPUT);
}

void steerSettingsInit()
{
    highLowPerDeg = ((float)(steerSettings.highPWM - steerSettings.lowPWM)) / LOW_HIGH_DEGREES;
}

void autosteerSetup()
{
    if      (PWM_Frequency == 0) { analogWriteFrequency(PWM1_LPWM, 490);  analogWriteFrequency(PWM2_RPWM, 490);  }
    else if (PWM_Frequency == 1) { analogWriteFrequency(PWM1_LPWM, 122);  analogWriteFrequency(PWM2_RPWM, 122);  }
    else if (PWM_Frequency == 2) { analogWriteFrequency(PWM1_LPWM, 3921); analogWriteFrequency(PWM2_RPWM, 3921); }

    pinMode(WORKSW_PIN,          INPUT_PULLUP);
    pinMode(STEERSW_PIN,         INPUT_PULLUP);
    pinMode(REMOTE_PIN,          INPUT_PULLUP);
    pinMode(DIR1_RL_ENABLE,      OUTPUT);
    pinMode(CURRENT_SENSOR_PIN,  INPUT_DISABLE);
    pinMode(PRESSURE_SENSOR_PIN, INPUT_DISABLE);

    EEPROM.get(0, EEread);
    if (EEread != EEP_Ident) {
        EEPROM.put(0,  EEP_Ident);
        EEPROM.put(10, steerSettings);
        EEPROM.put(40, steerConfig);
        EEPROM.put(60, networkAddress);
    } else {
        EEPROM.get(10, steerSettings);
        EEPROM.get(40, steerConfig);
        EEPROM.get(60, networkAddress);
    }

    steerSettingsInit();
    wasOffsetF = (float)steerSettings.wasOffset * 0.01f;
    steerConfigInit();

    if (Autosteer_running) {
        Serial.println("Autosteer running, waiting for AgOpenGPS");
        digitalWrite(AUTOSTEER_ACTIVE_LED,   0);
        digitalWrite(AUTOSTEER_STANDBY_LED,  1);
    } else {
        Autosteer_running = false;
        Serial.println("Autosteer disabled, GPS only mode");
        return;
    }

//Wire1.end();
//pinMode(DIR1_RL_ENABLE, OUTPUT);
//pinMode(PWM1_LPWM,      OUTPUT);  
//pinMode(PWM2_RPWM,      OUTPUT);


}

// ===================================================================
void autosteerLoop()
{
    ReceiveUdp();

    currentTime = systick_millis_count;
    if (currentTime - autsteerLastTime < LOOP_TIME) return;
    autsteerLastTime = currentTime;

    encEnable = true;

    if (watchdogTimer++ > 250) {
        watchdogTimer = WATCHDOG_FORCE_VALUE;
        steerSwitch  = 1;
        currentState = 1;
    }

    workSwitch = digitalRead(WORKSW_PIN);
    reading    = digitalRead(STEERSW_PIN);

    if (steerConfig.SteerSwitch == 1) {
        if (reading == HIGH) { currentState = 1; steerSwitch = 1; previous = reading; }
    }

    if (guidanceStatusChanged) {
        if (guidanceStatus == 1) { currentState = 0; steerSwitch = 0; }
    }

    static int switchCounter = 0;
    if (steerSwitch == 0 && guidanceStatus == 0) {
        if (switchCounter++ > 30) { currentState = 1; steerSwitch = 1; }
    } else { switchCounter = 0; }

    if (reading == LOW && previous == HIGH) {
        if (currentState == 1) { currentState = 0; steerSwitch = 0; }
        else                   { currentState = 1; steerSwitch = 1; }
    }
    previous = reading;

    if (steerConfig.ShaftEncoder && pulseCount >= steerConfig.PulseCountMax)
        { steerSwitch = 1; currentState = 1; previous = 0; }

    if (steerConfig.PressureSensor) {
        sensorSample  = (float)analogRead(PRESSURE_SENSOR_PIN) * 0.25f;
        sensorReading = sensorReading * 0.6f + sensorSample * 0.4f;
        if (sensorReading >= steerConfig.PulseCountMax)
            { steerSwitch = 1; currentState = 1; previous = 0; }
    }

    if (steerConfig.CurrentSensor) {
        sensorSample  = fabs(775.0f - (float)analogRead(CURRENT_SENSOR_PIN)) * 0.5f;
        sensorReading = min(sensorReading * 0.7f + sensorSample * 0.3f, 255.0f);
        if (sensorReading >= steerConfig.PulseCountMax)
            { steerSwitch = 1; currentState = 1; previous = 0; }
    }

    remoteSwitch = digitalRead(REMOTE_PIN);
    switchByte   = 0;
    switchByte  |= (remoteSwitch << 2);
    switchByte  |= (steerSwitch  << 1);
    switchByte  |= workSwitch;

    // ================================================================
    // OKREŚLENIE KĄTA SKRĘTU (WAS)
    // ================================================================
#ifdef USE_BNO_WAS

    // --- surowe yaw (stopnie) ---
    float yawCh_raw = TM1_YawDeg;                     // TM171 chassis (Serial5)
    float yawKn_raw = bnoDataWAS.yawX10 / 10.0f;      // BNO085 knuckle (Serial3)
    bool wasSensorsFresh = useTM171 && (TM171lastData < WAS_SENSOR_FRESH_MS) &&
                           useBNO08xRVC_WAS && (bnoWasLastData < WAS_SENSOR_FRESH_MS);

    // ---------- INTEGRATOR – CHASSIS ----------
    static bool  yawCh_init  = false;
    static float yawCh_prev  = 0.0f;
    static float yawCh_integ = 0.0f;

    if (!yawCh_init) { yawCh_prev = yawCh_raw; yawCh_integ = 0.0f; yawCh_init = true; }

    if (wasSensorsFresh) {
    float dYawCh = yawCh_raw - yawCh_prev;
    while (dYawCh >  180.0f) dYawCh -= 360.0f;
    while (dYawCh < -180.0f) dYawCh += 360.0f;

    // Korekcja dryfu chassis TM171 – wpisz błąd po pełnym obrocie 360°:
    const float CH_DRIFT_LEFT_360  = -2.1f;   // błąd przy obrocie W LEWO
    const float CH_DRIFT_RIGHT_360 = -2.1f;   // błąd przy obrocie W PRAWO
    float CH_SCALE_LEFT  = 1.0f - (CH_DRIFT_LEFT_360  / 360.0f);
    float CH_SCALE_RIGHT = 1.0f - (CH_DRIFT_RIGHT_360 / 360.0f);

    if (dYawCh > 0) yawCh_integ += dYawCh * CH_SCALE_RIGHT;
    else            yawCh_integ += dYawCh * CH_SCALE_LEFT;
    yawCh_prev = yawCh_raw;
    } else {
        yawCh_prev = yawCh_raw;
    }

    // ---------- INTEGRATOR – KNUCKLE ----------
    static bool  yawKn_init  = false;
    static float yawKn_prev  = 0.0f;
    static float yawKn_integ = 0.0f;

    if (!yawKn_init) { yawKn_prev = yawKn_raw; yawKn_integ = 0.0f; yawKn_init = true; }

    if (wasSensorsFresh) {
    float dYawKn = yawKn_raw - yawKn_prev;
    while (dYawKn >  180.0f) dYawKn -= 360.0f;
    while (dYawKn < -180.0f) dYawKn += 360.0f;

    // Korekcja dryfu knuckle BNO085 – wpisz błąd po pełnym obrocie 360°:
    const float KN_DRIFT_LEFT_360  = 0.1f;
    const float KN_DRIFT_RIGHT_360 = 0.1f;
    float KN_SCALE_LEFT  = 1.0f - (KN_DRIFT_LEFT_360  / 360.0f);
    float KN_SCALE_RIGHT = 1.0f - (KN_DRIFT_RIGHT_360 / 360.0f);

    if (dYawKn > 0) yawKn_integ += dYawKn * KN_SCALE_RIGHT;
    else            yawKn_integ += dYawKn * KN_SCALE_LEFT;
    yawKn_prev = yawKn_raw;
    } else {
        yawKn_prev = yawKn_raw;
        stableStart = 0;
    }

    // ---------- DELTA = kąt skrętu ----------
    float rawDeltaBase = yawKn_integ - yawCh_integ;
    while (rawDeltaBase >  180.0f) rawDeltaBase -= 360.0f;
    while (rawDeltaBase < -180.0f) rawDeltaBase += 360.0f;

    static bool deltaBaseInit = false;
    static float acceptedDeltaBase = 0.0f;
    static uint8_t badDeltaStepCount = 0;

    if (!deltaBaseInit) {
        acceptedDeltaBase = rawDeltaBase;
        deltaBaseInit = true;
    } else {
        float deltaStep = rawDeltaBase - acceptedDeltaBase;
        while (deltaStep >  180.0f) deltaStep -= 360.0f;
        while (deltaStep < -180.0f) deltaStep += 360.0f;

        bool impossibleStep = wasSensorsFresh &&
                              (WAS_MAX_DELTA_STEP_DEG > 0.0f) &&
                              (fabs(deltaStep) > WAS_MAX_DELTA_STEP_DEG);

        if (impossibleStep) {
            badDeltaStepCount++;
            if (WAS_ACCEPT_BAD_AFTER_CNT > 0 && badDeltaStepCount >= WAS_ACCEPT_BAD_AFTER_CNT) {
                acceptedDeltaBase = rawDeltaBase;
                badDeltaStepCount = 0;
            }
        } else {
            acceptedDeltaBase = rawDeltaBase;
            badDeltaStepCount = 0;
        }
    }

    float deltaBase = acceptedDeltaBase;

    float delta = deltaBase;
    if (steerConfig.InvertWAS) delta *= -1.0f;

    // CPD scale (70%–130%)
    float cpdScale = 0.7f + ((float)steerSettings.steerSensorCounts / 255.0f) * 0.6f;
    delta *= cpdScale;

    steerAngleActual = delta - wasOffsetF;

    if (steerAngleActual < 0.0f) steerAngleActual *= steerSettings.AckermanFix;

    // ---- WAS FREEZE ----
    {
        uint32_t nowMs = millis();
        float deltaRate = 0.0f;
        if (lastDeltaMs != 0) {
            float dt = (nowMs - lastDeltaMs) / 1000.0f;
            if (dt > 0.001f) {
                float d = deltaBase - lastDeltaBase;
                while (d >  180.0f) d -= 360.0f;
                while (d < -180.0f) d += 360.0f;
                deltaRate = d / dt;
            }
        }
        lastDeltaBase = deltaBase;
        lastDeltaMs   = nowMs;

        bool moving        = (gpsSpeed > FREEZE_SPEED_KMH);
        bool steeringMoved = (fabs(deltaRate) > THAW_RATE_DPS);

        if (!moving && !steeringMoved) {
            if (stillStartMs == 0) stillStartMs = nowMs;
            if (!wasFrozen && (nowMs - stillStartMs > FREEZE_TIME_MS)) {
                wasFrozen       = true;
                frozenWAS       = steerAngleActual;
                frozenDeltaBase = deltaBase;
            }
        } else {
            stillStartMs = 0;
        }

        if (wasFrozen && (moving || steeringMoved)) {
            wasFrozen = false;
            float curDelta = yawKn_integ - yawCh_integ;
            while (curDelta >  180.0f) curDelta -= 360.0f;
            while (curDelta < -180.0f) curDelta += 360.0f;
            float shift = frozenDeltaBase - curDelta;
            while (shift >  180.0f) shift -= 360.0f;
            while (shift < -180.0f) shift += 360.0f;
            yawKn_integ += shift;
            acceptedDeltaBase = frozenDeltaBase;
            rawDeltaBase = frozenDeltaBase;
            badDeltaStepCount = 0;
            yawCh_prev   = yawCh_raw;
            yawKn_prev   = yawKn_raw;
        }

        if (wasFrozen) steerAngleActual = frozenWAS;
    }

    // ---- AUTO-ZERO ----
    if (gpsSpeed > AUTOZERO_SPEED_MIN_KMH && useBNO08xRVC_WAS && bnoWasLastData < WAS_SENSOR_FRESH_MS) {
        static float    lastYaw  = 0.0f;
        static uint32_t lastTime = 0;
        float yawNow = TM1_YawDeg;

        float dYaw = yawNow - lastYaw;
        while (dYaw >  180.0f) dYaw -= 360.0f;
        while (dYaw < -180.0f) dYaw += 360.0f;

        uint32_t now = millis();
        float dt = (lastTime == 0) ? 0.025f : (now - lastTime) / 1000.0f;
        if (dt < 0.001f) dt = 0.001f;
        float yawRate = fabs(dYaw) / dt;
        lastYaw  = yawNow;
        lastTime = now;

        float absWas = fabs(steerAngleActual);
        bool straightMotion = yawRate < AUTOZERO_YAWRATE_MAX_DPS;
        bool targetStraight = fabs(steerAngleSetPoint) < AUTOZERO_SETPOINT_MAX_DEG;

        if (straightMotion && targetStraight) {
            if (stableStart == 0) stableStart = now;
            if (now - stableStart > AUTOZERO_STRAIGHT_TIME_MS) {
                float beta = (absWas > AUTOZERO_FAST_FROM_DEG) ? AUTOZERO_FAST_BETA : AUTOZERO_SLOW_BETA;
                float correction = beta * steerAngleActual;
                if (AUTOZERO_MAX_STEP_DEG > 0.0f)
                    correction = constrain(correction, -AUTOZERO_MAX_STEP_DEG, AUTOZERO_MAX_STEP_DEG);
                wasOffsetF += correction;
                steerSettings.wasOffset = (int16_t)round(wasOffsetF * 100.0f);
            }
        } else {
            stableStart = 0;
        }
    } else {
        stableStart = 0;
    }

#else
    // --- Oryginalny analogowy WAS ---
    if (steerConfig.InvertWAS) {
        steeringPosition = (steeringPosition - 6805 - steerSettings.wasOffset);
        steerAngleActual = (float)(steeringPosition) / -steerSettings.steerSensorCounts;
    } else {
        steeringPosition = (steeringPosition - 6805 + steerSettings.wasOffset);
        steerAngleActual = (float)(steeringPosition) /  steerSettings.steerSensorCounts;
    }
    if (steerAngleActual < 0.0f) steerAngleActual *= steerSettings.AckermanFix;

    float mappedWAS = multiMap<float>(steerAngleActual, inputWAS, outputWAS, 21);
    steerAngleActual = mappedWAS;
#endif

    // ================================================================
    // STEROWANIE SILNIKIEM
    // ================================================================
    if (watchdogTimer < WATCHDOG_THRESHOLD)
    {
        if (steerConfig.CytronDriver) {
            digitalWrite(PWM2_RPWM, steerConfig.IsRelayActiveHigh ? 0 : 1);
        } else {
            digitalWrite(DIR1_RL_ENABLE, 1);
        }

        steerAngleError = steerAngleActual - steerAngleSetPoint;
        if (gpsSpeed < 0.2) steerAngleError = 0;

        calcSteeringPID();
        motorDrive();
        digitalWrite(AUTOSTEER_ACTIVE_LED,  1);
        digitalWrite(AUTOSTEER_STANDBY_LED, 0);
    }
    else
    {
        if (steerConfig.CytronDriver) {
            digitalWrite(PWM2_RPWM, steerConfig.IsRelayActiveHigh ? 1 : 0);
        } else {
            digitalWrite(DIR1_RL_ENABLE, 0);
        }
        pwmDrive = 0;
        motorDrive();
        pulseCount = 0;
        digitalWrite(AUTOSTEER_STANDBY_LED, 1);
        digitalWrite(AUTOSTEER_ACTIVE_LED,  0);
    }

    // Speed pulse
    if (gpsSpeedUpdateTimer < 1000) {
        if (speedPulseUpdateTimer > 200) {
            speedPulseUpdateTimer = 0;
            float speedPulse = gpsSpeed * 36.1111f;
            if (gpsSpeed > 0.11f) tone(velocityPWM_Pin,  uint16_t(speedPulse));
            else                  noTone(velocityPWM_Pin);
        }
    } else {
        noTone(velocityPWM_Pin);
    }

    if (encEnable) {
        thisEnc = digitalRead(REMOTE_PIN);
        if (thisEnc != lastEnc) {
            lastEnc = thisEnc;
            if (lastEnc) EncoderFunc();
        }
    }
}

// ===================================================================
void ReceiveUdp()
{
    uint16_t len = Eth_udpAutoSteer.parsePacket();
    if (len <= 4) return;

    memset(autoSteerUdpData, 0, sizeof(autoSteerUdpData));
    uint16_t readLen = min(len, (uint16_t)sizeof(autoSteerUdpData));
    Eth_udpAutoSteer.read(autoSteerUdpData, readLen);

    if (autoSteerUdpData[0] != 0x80 || autoSteerUdpData[1] != 0x81 || autoSteerUdpData[2] != 0x7F) return;

    if (autoSteerUdpData[3] == 0xFE && Autosteer_running && readLen >= 13)   // 254
    {
        gpsSpeed = ((float)(autoSteerUdpData[5] | autoSteerUdpData[6] << 8)) * 0.1f;
        gpsSpeedUpdateTimer = 0;

        prevGuidanceStatus    = guidanceStatus;
        guidanceStatus        = autoSteerUdpData[7];
        guidanceStatusChanged = (guidanceStatus != prevGuidanceStatus);

        steerAngleSetPoint = ((float)(autoSteerUdpData[8] | ((int8_t)autoSteerUdpData[9]) << 8)) * 0.01f;

        if ((bitRead(guidanceStatus, 0) == 0) || (steerSwitch == 1))
             watchdogTimer = WATCHDOG_FORCE_VALUE;
        else watchdogTimer = 0;

        tram    = autoSteerUdpData[10];
        relay   = autoSteerUdpData[11];
        relayHi = autoSteerUdpData[12];

        int16_t sa = (int16_t)(steerAngleActual * 100);
        PGN_253[5] = (uint8_t)sa;
        PGN_253[6] = sa >> 8;
        PGN_253[7] = (uint8_t)9999; PGN_253[8] = 9999 >> 8;
        PGN_253[9] = (uint8_t)8888; PGN_253[10]= 8888 >> 8;
        PGN_253[11] = switchByte;
        PGN_253[12] = (uint8_t)pwmDisplay;

        int16_t CK_A = 0;
        for (uint8_t i = 2; i < PGN_253_Size; i++) CK_A += PGN_253[i];
        PGN_253[PGN_253_Size] = CK_A;
        SendUdp(PGN_253, sizeof(PGN_253), Eth_ipDestination, portDestination);

        if (steerConfig.PressureSensor || steerConfig.CurrentSensor) {
            if (aog2Count++ > 2) {
                PGN_250[5] = (byte)sensorReading;
                CK_A = 0;
                for (uint8_t i = 2; i < PGN_250_Size; i++) CK_A += PGN_250[i];
                PGN_250[PGN_250_Size] = CK_A;
                SendUdp(PGN_250, sizeof(PGN_250), Eth_ipDestination, portDestination);
                aog2Count = 0;
            }
        }
    }
    else if (autoSteerUdpData[3] == 0xFC && Autosteer_running && readLen >= 13)  // 252 settings
    {
        steerSettings.Kp               = autoSteerUdpData[5];
        steerSettings.highPWM          = autoSteerUdpData[6];
        steerSettings.lowPWM           = autoSteerUdpData[7];
        steerSettings.minPWM           = autoSteerUdpData[8];
        float temp = (float)steerSettings.minPWM * 1.2f;
        steerSettings.lowPWM           = (byte)temp;
        steerSettings.steerSensorCounts= autoSteerUdpData[9];
        steerSettings.wasOffset        = autoSteerUdpData[10] | (autoSteerUdpData[11] << 8);
        wasOffsetF = (float)steerSettings.wasOffset * 0.01f;
        steerSettings.AckermanFix      = (float)autoSteerUdpData[12] * 0.01f;
        EEPROM.put(10, steerSettings);
        steerSettingsInit();
    }
    else if (autoSteerUdpData[3] == 0xFB && readLen >= 9)  // 251 steer config
    {
        uint8_t sett = autoSteerUdpData[5];
        steerConfig.InvertWAS           = bitRead(sett,0);
        steerConfig.IsRelayActiveHigh   = bitRead(sett,1);
        steerConfig.MotorDriveDirection = bitRead(sett,2);
        steerConfig.SingleInputWAS      = bitRead(sett,3);
        steerConfig.CytronDriver        = bitRead(sett,4);
        steerConfig.SteerSwitch         = bitRead(sett,5);
        steerConfig.SteerButton         = bitRead(sett,6);
        steerConfig.ShaftEncoder        = bitRead(sett,7);
        steerConfig.PulseCountMax       = autoSteerUdpData[6];
        sett = autoSteerUdpData[8];
        steerConfig.IsDanfoss           = bitRead(sett,0);
        steerConfig.PressureSensor      = bitRead(sett,1);
        steerConfig.CurrentSensor       = bitRead(sett,2);
        steerConfig.IsUseY_Axis         = bitRead(sett,3);
        EEPROM.put(40, steerConfig);
        steerConfigInit();
    }
    else if (autoSteerUdpData[3] == 200)  // Hello from AgIO
    {
        if (Autosteer_running) {
            int16_t sa = (int16_t)(steerAngleActual * 100);
            helloFromAutoSteer[5] = (uint8_t)sa;
            helloFromAutoSteer[6] = sa >> 8;
            helloFromAutoSteer[7] = (uint8_t)helloSteerPosition;
            helloFromAutoSteer[8] = helloSteerPosition >> 8;
            helloFromAutoSteer[9] = switchByte;
            SendUdp(helloFromAutoSteer, sizeof(helloFromAutoSteer), Eth_ipDestination, portDestination);
        }
        if (useBNO08xRVC || useBNO08xI2C || useTM171)
            SendUdp(helloFromIMU, sizeof(helloFromIMU), Eth_ipDestination, portDestination);
    }
    else if (autoSteerUdpData[3] == 201 && readLen >= 10) {
        if (autoSteerUdpData[4] == 5 && autoSteerUdpData[5] == 201 && autoSteerUdpData[6] == 201) {
            networkAddress.ipOne   = autoSteerUdpData[7];
            networkAddress.ipTwo   = autoSteerUdpData[8];
            networkAddress.ipThree = autoSteerUdpData[9];
            EEPROM.put(60, networkAddress);
            SCB_AIRCR = 0x05FA0004;  // reset
        }
    }
    else if (autoSteerUdpData[3] == 202 && readLen >= 7) {
        if (autoSteerUdpData[4] == 3 && autoSteerUdpData[5] == 202 && autoSteerUdpData[6] == 202) {
            IPAddress rem_ip = Eth_udpAutoSteer.remoteIP();
            uint8_t scanReply[] = { 128,129,Eth_myip[3],203,7,
                Eth_myip[0],Eth_myip[1],Eth_myip[2],Eth_myip[3],
                rem_ip[0],rem_ip[1],rem_ip[2],23 };
            int16_t CK_A = 0;
            for (uint8_t i = 2; i < sizeof(scanReply)-1; i++) CK_A += scanReply[i];
            scanReply[sizeof(scanReply)-1] = CK_A;
            static uint8_t ipDest[] = { 255,255,255,255 };
            SendUdp(scanReply, sizeof(scanReply), ipDest, 9999);
        }
    }
}

#ifdef ARDUINO_TEENSY41
void SendUdp(uint8_t *data, uint8_t datalen, IPAddress dip, uint16_t dport)
{
    Eth_udpAutoSteer.beginPacket(dip, dport);
    Eth_udpAutoSteer.write(data, datalen);
    Eth_udpAutoSteer.endPacket();
}
#endif

void EncoderFunc()
{
    if (encEnable) { pulseCount++; encEnable = false; }
}

template<typename T>
T multiMap(T value, T* _in, T* _out, uint8_t size)
{
    if (value <= _in[0])       return _out[0];
    if (value >= _in[size-1])  return _out[size-1];
    uint8_t pos = 1;
    while (value > _in[pos]) pos++;
    if (value == _in[pos]) return _out[pos];
    return (value - _in[pos-1]) * (_out[pos] - _out[pos-1]) / (_in[pos] - _in[pos-1]) + _out[pos-1];
}
