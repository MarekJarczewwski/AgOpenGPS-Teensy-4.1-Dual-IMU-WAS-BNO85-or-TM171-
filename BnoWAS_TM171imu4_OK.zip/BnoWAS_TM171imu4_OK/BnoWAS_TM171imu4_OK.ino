// AgOpenGPS Autosteer – Teensy 4.1
// TM171  → Serial5 (pin 21) → chassis IMU  → TM1_YawDeg
// BNO085 → Serial3 (pin 7)  → knuckle WAS  → bnoDataWAS
//
// Pinout:
//   Serial7 RX (28) → F9P Position TX1
//   Serial7 TX (29) → F9P Position RX1
//   Serial2 RX  (9) → F9P Heading TX1
//   Serial2 TX (10) → F9P Heading RX1
//   Serial5 RX (21) → TM171 chassis TX
//   Serial3 RX  (7) → BNO085 knuckle WAS TX

/************************* User Settings *************************/

#define SerialAOG   Serial
#define SerialRTK   Serial8
HardwareSerial* SerialGPS  = &Serial7;
HardwareSerial* SerialGPS2 = &Serial2;

HardwareSerial* SerialBNO_WAS = &Serial3;   // BNO085 knuckle WAS (pin 7)

const int32_t baudAOG = 115200;
const int32_t baudGPS = 460800;
const int32_t baudRTK = 9600;

#define ImuWire Wire
#define RAD_TO_DEG_X_10 572.95779513082320876798154814105
#define RAD_TO_DEG      57.295779513082320876798154814105

const bool invertRoll = true;
#define baseLineLimit 5
#define REPORT_INTERVAL 20

#define GGAReceivedLED          13
#define Power_on_LED             5
#define Ethernet_Active_LED      6
#define GPSRED_LED               9
#define GPSGREEN_LED            10
#define AUTOSTEER_STANDBY_LED   11
#define AUTOSTEER_ACTIVE_LED    12

/*****************************************************************/

#include "zNMEAParser.h"
#include <Wire.h>
#include "BNO08x_AOG.h"
#include "BNO_RVC.h"
#include "RunningAverage.h"
#include "DHCP.h"

#ifdef ARDUINO_TEENSY41
#include <NativeEthernet.h>
#include <NativeEthernetUdp.h>

struct ConfigIP {
    uint8_t ipOne   = 192;
    uint8_t ipTwo   = 168;
    uint8_t ipThree = 5;
}; ConfigIP networkAddress;

byte Eth_myip[4]  = { 0, 0, 0, 0 };
byte mac[]        = { 0x00, 0x00, 0x56, 0x00, 0x00, 0x78 };

unsigned int portMy            = 5120;
unsigned int AOGNtripPort      = 2233;
unsigned int AOGAutoSteerPort  = 8888;
unsigned int portDestination   = 9999;

constexpr uint16_t ntrip_udp_buffer_size = 1024;
char Eth_NTRIP_packetBuffer[ntrip_udp_buffer_size];
char Eth_DHCP_packetBuffer[DHCP_MESSAGE_SIZE];
char domainName[] = "agopengps.com";

EthernetUDP Eth_udpPAOGI;
EthernetUDP Eth_udpNtrip;
EthernetUDP Eth_udpAutoSteer;
EthernetUDP Eth_udpDHCP;

IPAddress Eth_ipDestination;
#endif

byte CK_A = 0;
byte CK_B = 0;
int  relposnedByteCount = 0;

elapsedMillis speedPulseUpdateTimer = 0;
byte velocityPWM_Pin = 36;

// Set to 1 only if your Teensy core supports HardwareSerial::addMemoryForRead().
// Some Arduino/Teensy installs expose HardwareSerial without these methods.
#define ENABLE_EXTRA_SERIAL_BUFFERS 0

constexpr int serial_buffer_size = 1024;
uint8_t GPSrxbuffer[serial_buffer_size];
uint8_t GPS2rxbuffer[serial_buffer_size];
uint8_t RTKrxbuffer[serial_buffer_size];

RunningAverage myRA(7);
int   samples = 0;
float avg     = 0;

extern "C" uint32_t set_arm_clock(uint32_t frequency);

bool useDual         = false;
bool dualReadyGGA    = false;
bool dualReadyRelPos = false;

bool useCMPS      = false;
bool useBNO08x    = false;
bool useBNO08xI2C = false;
bool useTM171     = false;

BNO_rvc     rvcWAS;
BNO_rvcData bnoDataWAS{};
bool useBNO08xRVC_WAS = false;

// Placeholder (chassis = TM171, nie BNO RVC)
BNO_rvc     rvc;
BNO_rvcData bnoData{};
bool useBNO08xRVC = false;

elapsedMillis TM171lastData;
bool imuTrigger = false;
elapsedMillis imuTimer;
elapsedMillis bnoTimer;
elapsedMillis bnoWasLastData = 10000;
elapsedMillis i2cBNOTimer   = 0;
elapsedMillis GGAReadyTime  = 10000;
elapsedMillis ethernetLinkCheck = 1000;
bool bnoTrigger = false;

#define CMPS14_ADDRESS 0x60
const uint8_t  bno08xAddresses[] = { 0x4A, 0x4B };
const int16_t  nrBNO08xAdresses  = sizeof(bno08xAddresses) / sizeof(bno08xAddresses[0]);
uint8_t  bno08xAddress;
BNO080   bno08x;
uint32_t READ_BNO_TIME = 0;

double headingcorr = 900;
double baseline = 0, rollDual = 0, relPosD = 0, heading = 0;

byte ackPacket[72] = { 0xB5, 0x62, 0x01, 0x3C, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00 };

NMEAParser<2> parser;

bool blink             = false;
bool Autosteer_running = true;
bool Ethernet_running  = false;
bool GGA_Available     = false;

float roll = 0, pitch = 0, yaw = 0;

double rollDelta, rollDeltaSmooth, correctionHeading;
double gyroDelta, imuGPS_Offset, gpsHeading, imuCorrected;
#define twoPI 6.28318530717958647692
#define PIBy2 1.57079632679489661923

void TM171setup();
void TM171process();
void TM171process2();
void TM171debugPrint();

// ===================================================================
void setup()
{
    delay(500);

    pinMode(GGAReceivedLED,        OUTPUT);
    pinMode(Power_on_LED,          OUTPUT);
    pinMode(Ethernet_Active_LED,   OUTPUT);
    pinMode(GPSRED_LED,            OUTPUT);
    pinMode(GPSGREEN_LED,          OUTPUT);
    pinMode(AUTOSTEER_STANDBY_LED, OUTPUT);
    pinMode(AUTOSTEER_ACTIVE_LED,  OUTPUT);

    parser.setErrorHandler(errorHandler);
    parser.addHandler("G-GGA", GGA_Handler);
    parser.addHandler("G-VTG", VTG_Handler);

    delay(10);
    Serial.begin(baudAOG);
    delay(10);
    Serial.println("Start setup");

    SerialGPS->begin(baudGPS);
#if ENABLE_EXTRA_SERIAL_BUFFERS
    SerialGPS->addMemoryForRead(GPSrxbuffer, serial_buffer_size);
#endif
    delay(10);
    SerialRTK.begin(baudRTK);
#if ENABLE_EXTRA_SERIAL_BUFFERS
    SerialRTK.addMemoryForRead(RTKrxbuffer, serial_buffer_size);
#endif
    delay(10);
    SerialGPS2->begin(baudGPS);
#if ENABLE_EXTRA_SERIAL_BUFFERS
    SerialGPS2->addMemoryForRead(GPS2rxbuffer, serial_buffer_size);
#endif
    Serial.println("GPS serials OK");

    Serial.println("\r\nStarting AutoSteer...");
    autosteerSetup();

    Serial.println("\r\nStarting Ethernet...");
    EthernetStart();

    Serial.println("\r\nStarting Hydraulics...");
    HydraulicSetup();

    Serial.println("\r\nStarting TM171 chassis IMU...");
    useCMPS = false;
    useBNO08x = false;
    useBNO08xI2C = false;
    TM171setup();
    delay(200);
    TM171process();
    if (TM171lastData <= 80) {
        Serial.println("TM171 chassis OK");
        useTM171 = true;
        imuHandler();
    } else {
        Serial.println("TM171 chassis NOT found");
    }

    // BNO085 knuckle WAS (Serial3)
    Serial.println("\r\nStarting BNO085 WAS (knuckle)...");
    SerialBNO_WAS->begin(115200);
    rvcWAS.begin(SerialBNO_WAS);
    {
        elapsedMillis t = 0;
        while (t < 1000) {
            if (rvcWAS.read(&bnoDataWAS)) {
                useBNO08xRVC_WAS = true;
                bnoWasLastData = 0;
                break;
            }
        }
    }

    Serial.print("useCMPS         = "); Serial.println(useCMPS);
    Serial.print("useBNO08x (I2C) = "); Serial.println(useBNO08x);
    Serial.print("useTM171        = "); Serial.println(useTM171);
    Serial.print("useBNO_WAS      = "); Serial.println(useBNO08xRVC_WAS);
    Serial.println("\r\nEnd setup, waiting for GPS...\r\n");
}

// ===================================================================
void loop()
{
    // GPS → parser
    uint16_t gpsBytesThisLoop = 0;
    while (SerialGPS->available() && gpsBytesThisLoop++ < 256)
        parser << SerialGPS->read();

    // RTK radio → GPS
    uint16_t rtkBytesThisLoop = 0;
    while (SerialRTK.available() && rtkBytesThisLoop++ < 128)
        SerialGPS->write(SerialRTK.read());

    // DHCP
#ifdef ARDUINO_TEENSY41
    {
        unsigned int pktDHCP = Eth_udpDHCP.parsePacket();
        if (pktDHCP > 0) {
            if (pktDHCP > sizeof(Eth_DHCP_packetBuffer)) pktDHCP = sizeof(Eth_DHCP_packetBuffer);
            Eth_udpDHCP.read(Eth_DHCP_packetBuffer, pktDHCP);
            pktDHCP = DHCPreply((RIP_MSG*)Eth_DHCP_packetBuffer, pktDHCP, Eth_myip, 10, domainName);
            Eth_udpDHCP.beginPacket(Eth_ipDestination, DHCP_CLIENT_PORT);
            Eth_udpDHCP.write(Eth_DHCP_packetBuffer, pktDHCP);
            Eth_udpDHCP.endPacket();
        }
    }
#endif

    // NTRIP via UDP
    udpNtrip();

    // Dual GPS send
    if (dualReadyGGA && dualReadyRelPos) {
        BuildNmea();
        dualReadyGGA    = false;
        dualReadyRelPos = false;
    }

    // SerialGPS2 RelPos
    uint16_t gps2BytesThisLoop = 0;
    while (SerialGPS2->available() && gps2BytesThisLoop++ < 256) {
        uint8_t c = SerialGPS2->read();
        if      (relposnedByteCount < 4 && c == ackPacket[relposnedByteCount]) relposnedByteCount++;
        else if (relposnedByteCount > 3) { ackPacket[relposnedByteCount] = c; relposnedByteCount++; }
        else    relposnedByteCount = 0;
    }
    if (relposnedByteCount > 71) {
        if (calcChecksum()) { digitalWrite(GPSRED_LED, LOW); useDual = true; relPosDecode(); }
        relposnedByteCount = 0;
    }

    // TM171 chassis
    TM171process();
    TM171process2();   // pusty stub

    // BNO085 knuckle WAS
    if (rvcWAS.read(&bnoDataWAS)) {
        useBNO08xRVC_WAS = true;
        bnoWasLastData = 0;
    }

    // IMU handler trigger
    if (useTM171 && imuTimer > 70 && imuTrigger) {
        imuTrigger = false;
        imuHandler();
    }

    // I2C BNO fallback
    if (useBNO08xI2C && i2cBNOTimer > 20) {
        i2cBNOTimer = 0;
        readBNO();
    }

    if (Autosteer_running) autosteerLoop();
    else                   ReceiveUdp();

    // GGA timeout
    if (GGAReadyTime > 10000) {
        digitalWrite(GPSRED_LED,   LOW);
        digitalWrite(GPSGREEN_LED, LOW);
        useDual = false;
    }

    // Ethernet LED
    if (ethernetLinkCheck > 10000) {
        ethernetLinkCheck = 0;
        if (Ethernet.linkStatus() == LinkON) {
            digitalWrite(Power_on_LED,        0);
            digitalWrite(Ethernet_Active_LED, 1);
        } else {
            digitalWrite(Power_on_LED,        1);
            digitalWrite(Ethernet_Active_LED, 0);
        }
    }
}

// ===================================================================
bool calcChecksum()
{
    CK_A = 0; CK_B = 0;
    for (int i = 2; i < 70; i++) { CK_A += ackPacket[i]; CK_B += CK_A; }
    return (CK_A == ackPacket[70] && CK_B == ackPacket[71]);
}
