// Conversion to Hex
const char* asciiHex = "0123456789ABCDEF";

char nmea[100];

// GGA fields
char fixTime[12];
char latitude[15];
char latNS[3];
char longitude[15];
char lonEW[3];
char fixQuality[2];
char numSats[4];
char HDOP[5];
char altitude[12];
char ageDGPS[10];

// VTG fields
char vtgHeading[12] = {};
char speedKnots[10] = {};

// IMU fields
char imuHeading[6];
char imuRoll[6];
char imuPitch[6];
char imuYawRate[6];

void errorHandler() {}

void GGA_Handler()
{
    parser.getArg(0,  fixTime);
    parser.getArg(1,  latitude);
    parser.getArg(2,  latNS);
    parser.getArg(3,  longitude);
    parser.getArg(4,  lonEW);
    parser.getArg(5,  fixQuality);
    parser.getArg(6,  numSats);
    parser.getArg(7,  HDOP);
    parser.getArg(8,  altitude);
    parser.getArg(12, ageDGPS);

    digitalWrite(GGAReceivedLED, blink ? HIGH : LOW);
    blink      = !blink;
    bnoTrigger = true;
    bnoTimer   = 0;

    if (useDual) {
        dualReadyGGA = true;
    }
    else if (useTM171) {
        // Chassis heading z TM171, roll z TM171
        imuHandler();
        BuildNmea();
        dualReadyGGA = false;
        if (!useDual) {
            digitalWrite(GPSRED_LED,   HIGH);
            digitalWrite(GPSGREEN_LED, LOW);
        }
    }
    else if (useBNO08xRVC || useBNO08xI2C) {
        imuHandler();
        BuildNmea();
        dualReadyGGA = false;
        if (!useDual) {
            digitalWrite(GPSRED_LED,   HIGH);
            digitalWrite(GPSGREEN_LED, LOW);
        }
    }
    else if (!useDual && !useBNO08xRVC && !useBNO08xI2C && !useTM171) {
        digitalWrite(GPSRED_LED,   blink);
        digitalWrite(GPSGREEN_LED, LOW);
        itoa(65535, imuHeading, 10);
        BuildNmea();
    }

    GGAReadyTime = 0;
}

void imuHandler()
{
    if (!useDual)
    {
        if (useTM171)
        {
            // Heading z TM171 chassis (w stopniach, skala x10 dla PANDA)
            // TM1_YawDeg jest w stopniach (0..360), PANDA oczekuje x10
            int16_t headingX10 = (int16_t)(TM1_YawDeg * 10.0f);
            if (headingX10 < 0) headingX10 += 3600;
            itoa(headingX10, imuHeading, 10);

            // Roll z TM171 – RollV.fValue (stopnie x10)
            itoa((int16_t)(RollV.fValue  * 10.0f), imuRoll,  10);
            itoa((int16_t)(PitchV.fValue * 10.0f), imuPitch, 10);
            itoa(0, imuYawRate, 10);
        }
        else if (useBNO08xRVC)
        {
            float angVel;
            itoa(bnoData.yawX10, imuHeading, 10);

            if (steerConfig.IsUseY_Axis) {
                itoa(bnoData.pitchX10, imuPitch, 10);
                itoa(bnoData.rollX10,  imuRoll,  10);
            } else {
                itoa(bnoData.rollX10,  imuPitch, 10);
                itoa(bnoData.pitchX10, imuRoll,  10);
            }

            if (rvc.angCounter > 0) {
                angVel = ((float)bnoData.angVel / (float)rvc.angCounter) * 10.0f;
                rvc.angCounter = 0;
                bnoData.angVel = (int16_t)angVel;
            } else {
                bnoData.angVel = 0;
            }
            itoa(bnoData.angVel, imuYawRate, 10);
            bnoData.angVel = 0;
        }
        else if (useBNO08xI2C)
        {
            itoa((int16_t)yaw,   imuHeading,  10);
            itoa((int16_t)pitch, imuPitch,    10);
            itoa((int16_t)roll,  imuRoll,     10);
            itoa(0,              imuYawRate,  10);
        }
    }
    else
    {
        dtostrf(rollDual, 4, 2, imuRoll);
        dtostrf(heading,  4, 2, imuHeading);
    }
}

void readBNO()
{
    if (!bno08x.dataAvailable()) return;

    float dqx, dqy, dqz, dqw, dacr;
    uint8_t dac;
    bno08x.getQuat(dqx, dqy, dqz, dqw, dacr, dac);

    float norm = sqrt(dqw*dqw + dqx*dqx + dqy*dqy + dqz*dqz);
    dqw /= norm; dqx /= norm; dqy /= norm; dqz /= norm;

    float ysqr = dqy * dqy;
    float t3   = 2.0f * (dqw*dqz + dqx*dqy);
    float t4   = 1.0f - 2.0f * (ysqr + dqz*dqz);
    yaw        = atan2(t3, t4);
    yaw        = (int16_t)(yaw * -RAD_TO_DEG_X_10);
    if (yaw < 0) yaw += 3600;

    float t2 = 2.0f * (dqw*dqy - dqz*dqx);
    t2 = constrain(t2, -1.0f, 1.0f);
    float t0 = 2.0f * (dqw*dqx + dqy*dqz);
    float t1 = 1.0f - 2.0f * (dqx*dqx + ysqr);

    if (steerConfig.IsUseY_Axis) {
        roll  = asin(t2)    * RAD_TO_DEG_X_10;
        pitch = atan2(t0,t1)* RAD_TO_DEG_X_10;
    } else {
        pitch = asin(t2)    * RAD_TO_DEG_X_10;
        roll  = atan2(t0,t1)* RAD_TO_DEG_X_10;
    }

    itoa((int16_t)yaw,   imuHeading, 10);
    itoa((int16_t)pitch, imuPitch,   10);
    itoa((int16_t)roll,  imuRoll,    10);
    itoa(0,              imuYawRate, 10);
}

void BuildNmea()
{
    strcpy(nmea, "");
    if (useDual) strcat(nmea, "$PAOGI,");
    else         strcat(nmea, "$PANDA,");

    strcat(nmea, fixTime);    strcat(nmea, ",");
    strcat(nmea, latitude);   strcat(nmea, ",");
    strcat(nmea, latNS);      strcat(nmea, ",");
    strcat(nmea, longitude);  strcat(nmea, ",");
    strcat(nmea, lonEW);      strcat(nmea, ",");
    strcat(nmea, fixQuality); strcat(nmea, ",");
    strcat(nmea, numSats);    strcat(nmea, ",");
    strcat(nmea, HDOP);       strcat(nmea, ",");
    strcat(nmea, altitude);   strcat(nmea, ",");
    strcat(nmea, ageDGPS);    strcat(nmea, ",");
    strcat(nmea, speedKnots); strcat(nmea, ",");
    strcat(nmea, imuHeading); strcat(nmea, ",");
    strcat(nmea, imuRoll);    strcat(nmea, ",");
    strcat(nmea, imuPitch);   strcat(nmea, ",");
    strcat(nmea, imuYawRate);
    strcat(nmea, "*");

    CalculateChecksum();
    strcat(nmea, "\r\n");

    int len = strlen(nmea);
    Eth_udpPAOGI.beginPacket(Eth_ipDestination, portDestination);
    Eth_udpPAOGI.write(nmea, len);
    Eth_udpPAOGI.endPacket();
}

void CalculateChecksum()
{
    int16_t sum = 0;
    for (int16_t inx = 1; inx < 200; inx++) {
        char tmp = nmea[inx];
        if (tmp == '*') break;
        sum ^= tmp;
    }
    char hex[2] = { asciiHex[sum >> 4], 0 };
    strcat(nmea, hex);
    char hex2[2] = { asciiHex[sum % 16], 0 };
    strcat(nmea, hex2);
}

void VTG_Handler()
{
    parser.getArg(0, vtgHeading);
    parser.getArg(4, speedKnots);
}
