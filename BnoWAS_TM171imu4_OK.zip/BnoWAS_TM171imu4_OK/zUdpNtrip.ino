void udpNtrip()
{
#ifdef ARDUINO_TEENSY41
  unsigned int packetLength = Eth_udpNtrip.parsePacket();

  if (packetLength > 0)
  {
    while (packetLength > 0)
    {
      uint16_t bytesToRead = (packetLength > sizeof(Eth_NTRIP_packetBuffer)) ? sizeof(Eth_NTRIP_packetBuffer) : packetLength;
      int bytesRead = Eth_udpNtrip.read(Eth_NTRIP_packetBuffer, bytesToRead);
      if (bytesRead <= 0) break;

      SerialGPS->write(Eth_NTRIP_packetBuffer, bytesRead);
      packetLength -= bytesRead;
    }
  }
#endif
}
